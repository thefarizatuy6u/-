
let page = 0;
const pages = [
    { text: "Страница 1: Введение в веб-программирование. HTML, CSS, JS — основа всего.", audio: "audio/page1.mp3" },
    { text: "Страница 2: HTML — структура страниц. Теги div, a, p.", audio: "audio/page2.mp3" },
    { text: "Страница 3: CSS — стили, цвета, шрифты, анимации.", audio: "audio/page3.mp3" },
    { text: "Страница 4: JavaScript — логика, действия, события.", audio: "audio/page4.mp3" },
    { text: "Страница 5: DOM — взаимодействие с HTML через JavaScript.", audio: "audio/page5.mp3" },
    { text: "Страница 6: Адаптивность — Flexbox, Grid, мобильная вёрстка.", audio: "audio/page6.mp3" },
    { text: "Страница 7: Фреймворки CSS — Bootstrap, Tailwind.", audio: "audio/page7.mp3" },
    { text: "Страница 8: Git и GitHub — контроль версий, коммиты, репозитории.", audio: "audio/page8.mp3" },
    { text: "Страница 9: Backend — Node.js, Express, PHP, взаимодействие с сервером.", audio: "audio/page9.mp3" },
    { text: "Страница 10: Базы данных — MySQL, MongoDB, CRUD-операции.", audio: "audio/page10.mp3" },
    { text: "Страница 11: API — REST, JSON, работа с внешними данными.", audio: "audio/page11.mp3" },
    { text: "Страница 12: Безопасность — HTTPS, XSS, защита данных.", audio: "audio/page12.mp3" },
    { text: "Страница 13: Продвинутый JavaScript — ES6+, async/await, промисы.", audio: "audio/page13.mp3" },
    { text: "Страница 14: Публикация сайта — хостинг, GitHub Pages, Netlify.", audio: "audio/page14.mp3" },
    { text: "Страница 15: Заключение — как стать веб-разработчиком.", audio: "audio/page15.mp3" }
];

const textBox = document.getElementById("textBox");
let sound;

function playAudio(src) {
    if (sound) sound.stop();
    sound = new Howl({ src: [src] });
    sound.play();
}

function showPage(n) {
    if (n < 0 || n >= pages.length) return;
    page = n;
    textBox.innerHTML = pages[page].text;
    playAudio(pages[page].audio);
}
function nextPage() { showPage(page + 1); }
function prevPage() { showPage(page - 1); }

// 3D scene init
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const geometry = new THREE.BoxGeometry();
const material = new THREE.MeshBasicMaterial({ color: 0x00ff00, wireframe: true });
const cube = new THREE.Mesh(geometry, material);
scene.add(cube);
camera.position.z = 5;

function animate() {
    requestAnimationFrame(animate);
    cube.rotation.x += 0.01;
    cube.rotation.y += 0.01;
    renderer.render(scene, camera);
}
animate();
showPage(0);
